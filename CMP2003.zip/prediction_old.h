#pragma once
#include <iostream>
#include <fstream>
#include<string>
#include <sstream>
#include "algorithm"
#include "cmath"
#include <unordered_map>
#include <vector>
#include <algorithm>
struct info{
    int ID;
    double rank;
};

class prediction_old{
public:
    bool compareMovies(const info &a, const info &b);
    prediction_old();
    ~prediction_old();
    void reading_input(std::string const& file_name);
    void mergeSort(info *movies, int left, int right);
    void merge(info *movies, int left, int mid, int right);
    void finding_rank();
    void setuser_length(int user);
    void setmovie_length(int movie);
    int getmovie_length()const;
    int getuser_length()const;
    void predict(std::string const& file_name);

private:
    info *rank_user;
    info *rank_movie;
    int **rec;
    double **dats;
    int user_length;
    int movie_length;
    int max_user = 0;
    int max_movie = 0;

};

int prediction_old::getmovie_length() const{
    return movie_length;
}

int prediction_old::getuser_length() const{
    return user_length;
}

void prediction_old::setuser_length(int user) {
    if(max_user <= user){
        max_user = user;
    }
    user_length = max_user;
}

void prediction_old::setmovie_length(int movie) {
    if(max_movie <= movie){
        max_movie = movie;
    }
    movie_length = max_movie;
}

bool prediction_old::compareMovies(const info &a, const info &b){
    return a.rank > b.rank;
}

void prediction_old::mergeSort(info *movies, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(movies, left, mid);
        mergeSort(movies, mid + 1, right);
        merge(movies, left, mid, right);
    }
}

void prediction_old::merge(info *movies, int left, int mid, int right) {
    int i = left;
    int j = mid + 1;
    int k = 0;
    info temp[right - left + 1];

    while (i <= mid && j <= right) {
        if (compareMovies(movies[i], movies[j])) {
            temp[k++] = movies[i++];
        } else {
            temp[k++] = movies[j++];
        }
    }

    while (i <= mid) {
        temp[k++] = movies[i++];
    }

    while (j <= right) {
        temp[k++] = movies[j++];
    }

    for (int l = 0; l < k; l++) {
        movies[left + l] = temp[l];
    }
}

void prediction_old::finding_rank() {

    mergeSort(rank_movie,0,getmovie_length());
    mergeSort(rank_user,0,getuser_length());

    std::cout << "--------FOR USERS-------------" << std::endl;

    for(int i = 0; i < 10; i++){
        if(rank_user[i].rank >= 1 ){
            std::cout << "User: " << rank_user[i].ID << " ranked a movie: " << rank_user[i].rank << " times" << std::endl;
        }
    }

    std::cout << "--------FOR MOVIES-------------" << std::endl;

    for(int i = 0; i < 10; i++){
        if(rank_movie[i].rank >= 1 ){
            std::cout << "Movie: " << rank_movie[i].ID << "  " << rank_movie[i].rank << " times ranked" << std::endl;
        }
    }
}

prediction_old::prediction_old() {
    dats = new double*[36000];
    rec = new int*[36000];
    for(int i = 0; i < 36000; i++){
        rec[i] = new int[8000];
        for(int k = 0; k < 8000; k++){
            rec[i][k] = 0;
        }
    }
    dats = new double*[36000];
    for(int k = 0; k <36000; ++k){
        dats[k] = new double[8000];
    }
    rank_user = new info[36000];
    rank_movie = new info[8000];
    for(int i = 0; i < 8000; i++){
        rank_movie[i].rank = 0;
    }
    for(int i = 0; i < 36000;i++){
        rank_user[i].rank = 0;
    }
}

void prediction_old::reading_input(std::string const& file_name) {
    std::ifstream input;
    input.open(file_name);
    std::string line;
    if(input.is_open()) {
        while (getline(input, line, ',')) {
            int a, b;
            double c;
            std::stringstream ss(line);
            ss >> a;
            getline(input, line, ',');
            std::stringstream ss1(line);
            ss1 >> b;
            getline(input, line, '\n');
            std::stringstream ss2(line);
            ss2 >> c;

            dats[a][b] = c;
            rec[a][b] = 1;
            rank_user[a].rank += 1;
            rank_user[a].ID = a;
            rank_movie[b].rank += 1;
            rank_movie[b].ID = b;
            setmovie_length(b);
            setuser_length(a);
        }
        input.close();
    }
}

void prediction_old::predict(std::string const& file_name) {
    std::ifstream input;
    input.open(file_name);
    std::string line;
    if (input.is_open()) {
        std::cout << "ID,Predicted" << std::endl;
        while (getline(input, line, ',')) {
            int a, b, c;
            std::stringstream ss(line);
            ss >> a;
            getline(input, line, ',');
            std::stringstream ss1(line);
            ss1 >> b;
            getline(input, line, '\n');
            std::stringstream ss2(line);
            ss2 >> c;
            double sum1 = 0.0;
            double sum2 = 0.0;
            double mul = 0.0;
            int k1 = 0; int k2 = 0; int k3 = 0; int k4 = 0; int k5 = 0;int k6 = 0;int k7 = 0;int k8 = 0;int k9 = 0;int k10 = 0;
            int k11 = 0;int k12 = 0;int k13 = 0;int k14 = 0;int k15 = 0;int k16 = 0;int k17 = 0;int k18 = 0;int k19 = 0;int k20 = 0;int k21 = 0;int k22 = 0;
            int k23 = 0;int k24 = 0;int k25 = 0;int k26 = 0;int k27 = 0;int k28 = 0;int k29 = 0;
            double avg;
            double similarity[36000];
            for(int i = 0; i < 36000;i++){
                if(rec[i][c] == 1 && i != b) {
                    for (int k = 0; k < 8000; k++) {
                        if(rec[i][k] == 1 && rec[b][k] == 1){
                            sum1 += pow(dats[i][k],2);
                            sum2 += pow(dats[b][k],2);
                            mul += dats[b][k] * dats[i][k];
                        }
                    }
                    if(sum1 != 0 && sum2 != 0)
                        similarity[i] = mul / (sqrt(sum1)* sqrt(sum2));
                }
            }
            int mostSimilarUser = 42;
            for(int k = 0; k < 36000;k++){
                if(k!= b){
                    if(similarity[k] > similarity[mostSimilarUser] && rec[k][c] == 1) {
                        mostSimilarUser = k;
                    }

                    else if(similarity[k] > similarity[k1] && rec[k][c] == 1 ){
                        k1 = k;
                    }
                    else if(similarity[k] > similarity[k2] && rec[k][c] == 1){
                        k2 = k;
                    }

                    else if(similarity[k] > similarity[k3] && rec[k][c] == 1){
                        k3 = k;
                    }
                    else if(similarity[k] > similarity[k4] && rec[k][c] == 1){
                        k4 = k;
                    }
                    else if(similarity[k] > similarity[k5] && rec[k][c] == 1){
                        k5 = k;
                    }
                    else if(similarity[k] > similarity[k6] && rec[k][c] == 1){
                        k6 = k;
                    }
                    else if(similarity[k] > similarity[k7] && rec[k][c] == 1){
                        k7 = k;
                    }
                    else if(similarity[k] > similarity[k8] && rec[k][c] == 1){
                        k8 = k;
                    }
                    else if(similarity[k] > similarity[k9] && rec[k][c] == 1){
                        k9 = k;
                    }
                    else if(similarity[k] > similarity[k10] && rec[k][c] == 1){
                        k10 = k;
                    }
                    else if(similarity[k] > similarity[k11] && rec[k][c] == 1){
                        k11 = k;
                    }
                    else if(similarity[k] > similarity[k12] && rec[k][c] == 1){
                        k12 = k;
                    }
                    else if(similarity[k] > similarity[k13] && rec[k][c] == 1){
                        k13 = k;
                    }
                    else if(similarity[k] > similarity[k14] && rec[k][c] == 1){
                        k14 = k;
                    }
                    else if(similarity[k] > similarity[k15] && rec[k][c] == 1){
                        k15 = k;
                    }
                    else if(similarity[k] > similarity[k16] && rec[k][c] == 1){
                        k16 = k;
                    }
                    else if(similarity[k] > similarity[k17] && rec[k][c] == 1){
                        k17 = k;
                    }
                    else if(similarity[k] > similarity[k18] && rec[k][c] == 1){
                        k18 = k;
                    }
                    else if(similarity[k] > similarity[k19] && rec[k][c] == 1){
                        k19 = k;
                    }
                    else if(similarity[k] > similarity[k20] && rec[k][c] == 1){
                        k20 = k;
                    }
                    else if(similarity[k] > similarity[k21] && rec[k][c] == 1){
                        k21 = k;
                    }
                    else if(similarity[k] > similarity[k22] && rec[k][c] == 1){
                        k22 = k;
                    }
                    else if(similarity[k] > similarity[k23] && rec[k][c] == 1){
                        k23 = k;
                    }
                    else if(similarity[k] > similarity[k24] && rec[k][c] == 1){
                        k24 = k;
                    }
                    else if(similarity[k] > similarity[k25] && rec[k][c] == 1){
                        k25 = k;
                    }
                    else if(similarity[k] > similarity[k26] && rec[k][c] == 1){
                        k26 = k;
                    }
                    else if(similarity[k] > similarity[k27] && rec[k][c] == 1){
                        k27 = k;
                    }
                    else if(similarity[k] > similarity[k28] && rec[k][c] == 1){
                        k28 = k;
                    }
                    else if(similarity[k] > similarity[k29] && rec[k][c] == 1){
                        k29 = k;
                    }
                }
            }
            avg = (dats[mostSimilarUser][c]*similarity[mostSimilarUser] + dats[k1][c]*similarity[k1] +
                    dats[k2][c]*similarity[k2] + dats[k3][c]*similarity[k3] + dats[k4][c]*similarity[k4] +dats[k5][c]*similarity[k5]+ dats[k6][c]*similarity[k6]+ dats[k7][c]*similarity[k7]+ dats[k8][c]*similarity[k8]+ dats[k9][c]*similarity[k9] + dats[k10][c]*similarity[k10]+ dats[k11][c]*similarity[k11]+ dats[k12][c]*similarity[k12]+ dats[k13][c]*similarity[k13]+ dats[k14][c]*similarity[k14]+ dats[k15][c]*similarity[k15]+ dats[k16][c]*similarity[k16]+ dats[k17][c]*similarity[k17]+ dats[k18][c]*similarity[k18]+ dats[k19][c]*similarity[k19]+ dats[k20][c]*similarity[k20]+ dats[k21][c]*similarity[k21]+ dats[k22][c]*similarity[k22]+ dats[k23][c]*similarity[k23]+ dats[k24][c]*similarity[k24]+ dats[k25][c]*similarity[k25]+ dats[k26][c]*similarity[k26]+ dats[k27][c]*similarity[k27]+ dats[k28][c]*similarity[k28]+ dats[k29][c]*similarity[k29])
                            /(similarity[mostSimilarUser]+similarity[k1]+similarity[k2]+similarity[k3]+similarity[k4]+similarity[k5]+similarity[k6]+similarity[k7]+similarity[k8]+similarity[k9]+similarity[k10]+similarity[k11]+similarity[k12]+similarity[k13]+similarity[k14]+similarity[k15]+similarity[k16]+similarity[k17]+similarity[k18]+similarity[k19]+similarity[k20]+similarity[k21]+similarity[k22]+similarity[k23]+similarity[k24]+similarity[k25]+similarity[k26]+similarity[k27]+similarity[k28]+similarity[k29]);

            std::cout << a << ", " << avg << std::endl;
        }
    }
    input.close();
}

prediction_old::~prediction_old() {
    for(int i = 0; i < 8000; ++i) {
        delete [] dats[i];
        delete [] rec[i];
    }
    delete [] dats;
    delete [] rec;
    delete rank_movie;
    delete rank_user;
}